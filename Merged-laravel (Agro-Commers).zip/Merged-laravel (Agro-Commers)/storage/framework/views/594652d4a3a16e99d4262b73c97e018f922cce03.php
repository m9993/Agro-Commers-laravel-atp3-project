<!DOCTYPE html>
<html>
<head>
	<title>Export Data</title>
</head>
<body>

	<div class="table-responsive">
    <table id="list_table" class="table table-bordered table-striped table-hover">
    <thead>
        <tr>
           <td><b>Date</b></td>
          <td><b>Headline</b></td>
          <td><b>Details</b></td>
         </tr>
    </thead>
    <tbody>
      <tr>
            <td><?php echo e($data->date); ?></td>
            <td><?php echo e($data->headline); ?></td>
            <td><?php echo e($data->detail); ?></td>
        </tr>
      </tbody>
  </table>
</div>

</body>
</html><?php /**PATH I:\AMERICAN INTERNATIONAL UNIVERSITY BANGLADESH\SEMESTER 11\Agro Commers(Laravel)\laravel-practice(my)\resources\views/home/exportdata.blade.php ENDPATH**/ ?>