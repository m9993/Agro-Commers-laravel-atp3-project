<!DOCTYPE html>
<html>
<head>
	<title>Edit Page</title>
</head>
<body>
	<a href="<?php echo e(route('home.index')); ?>">Back</a> |
	<a href="/logout">logout</a>
	<br>
	
		<form method="post" enctype="multipart/form-data">

			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
			<fieldset>
				<legend>Edit News</legend>
			<table>
				<tr>
					<td>News ID</td>
					<td><input type="text" name="newsid" value="<?php echo e($newsid); ?>"></td>
				</tr>
				<tr>
					<td>Date</td>
					<td><input type="text" name="date" value="<?php echo e($date); ?>"></td>
				</tr>
				<tr>
					<td>Headline</td>
					<td><input type="text" name="headline" value="<?php echo e($headline); ?>"></td>
				</tr>
				<tr>
					<td>Details</td>
					<td><input type="text" name="detail" value="<?php echo e($detail); ?>"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="submit" value="Update"></td>
				</tr>
			</table>
			</fieldset>
		</form>

		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php echo e($err); ?> <br>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html><?php /**PATH I:\AMERICAN INTERNATIONAL UNIVERSITY BANGLADESH\SEMESTER 11\Agro Commers(Laravel)\laravel-practice(my)\resources\views/home/editnews.blade.php ENDPATH**/ ?>