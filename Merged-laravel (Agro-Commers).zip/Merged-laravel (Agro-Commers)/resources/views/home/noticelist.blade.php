<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Agro-Commers</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="/img/favicon.ico" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="{{asset('css/style.css')}}" rel="stylesheet" />
        <script type = "text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script type="text/javascript" src = "/assets/js/main2.js"></script>
    </head>
    <body id="page-top">
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg bg-secondary text-uppercase fixed-top" id="mainNav">
            <div class="container">
                <a class="navbar-brand js-scroll-trigger" href="{{route('home.index')}}">Agro-Commer</a>
                <button class="navbar-toggler navbar-toggler-right text-uppercase font-weight-bold bg-primary text-white rounded" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fas fa-bars m-0 p-0 mx-1"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item mx-0 mx-lg-1"><a href="#contact" class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger"><i class="fas fa-envelope mr-1 pr-1"></i>Contact</a></li>
                        <li class="nav-item mx-0 mx-lg-1"><a href="/logout" class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger"><i class="fas fa-sign-out-alt mr-1 pr-1"></i>Logout</a></li>
                    </ul>
                </div>
            </div>
        </nav>
               <!-- Body Section-->
        <section class="page-section portfolio" id="portfolio">
            <div class="container">
                <!-- ---------------Body start---------------- -->












                <!-- ---------------Body End---------------- -->
            </div>
        </section>




       
        <!-- Contact Section-->
        <section class="page-section" id="contact">
            <hr>
            <div class="my-class">
        <input id="searchKey" name="searchKey"  type="text" placeholder="Search by notice">
    </div>
           <table border="1" class="center" id="table">

        <tr>
            <th>ID</th>
            <th>User ID</th>
            <th>Notice</th>
            <th>Action</th>
        </tr>
        
        <!-- <% for(var i=0; i < users.length; i++){ %>
            
            <tr>
                <td><%= users[i][0] %></td>
                <td><%= users[i][1] %></td>
                <td><%= users[i][2] %></td>
                <td><%= users[i][3] %></td>
            </tr>
        <% } %> -->
           <tbody id='table-body'>
        @for($i=0; $i < count($users); $i++)
        <tr>
            <td>{{$users[$i]['nid']}}</td>
            <td>{{$users[$i]['uid']}}</td>
            <td>{{$users[$i]['notice']}}</td>
            <td>
                <a href="/notice/edit/{{$users[$i]['nid']}}">Edit</a> |
                <a href="/notice/delete/{{$users[$i]['nid']}}">Delete</a>
            </td>
        </tr>
        @endfor
    </tbody>
    </table>
    <div class="my-class">
        <a href="/notice/create" class="center">New Notice</a>
        </div>
        </section>
        <!-- Footer-->
        <footer class="footer text-center">
            <div class="container">
                <div class="row">
                    <!-- Footer Location-->
                    <div class="col-lg-4 mb-5 mb-lg-0">
                        <h4 class="text-uppercase mb-4">Location</h4>
                        <p class="lead mb-0">
                            1212 Gulshan-2
                            <br />
                            Dhaka, Bangladesh
                        </p>
                    </div>
                    <!-- Footer Social Icons-->
                    <div class="col-lg-4 mb-5 mb-lg-0">
                        <h4 class="text-uppercase mb-4">Around the Web</h4>
                        <a class="btn btn-outline-light btn-social mx-1" href="#!"><i class="fab fa-fw fa-facebook-f"></i></a>
                        <a class="btn btn-outline-light btn-social mx-1" href="#!"><i class="fab fa-fw fa-twitter"></i></a>
                        <a class="btn btn-outline-light btn-social mx-1" href="#!"><i class="fab fa-fw fa-linkedin-in"></i></a>
                        <a class="btn btn-outline-light btn-social mx-1" href="#!"><i class="fab fa-fw fa-dribbble"></i></a>
                    </div>
                    <!-- Footer About Text-->
                    <div class="col-lg-4">
                        <h4 class="text-uppercase mb-4">About</h4>
                        <p class="lead mb-0">
                            We sell all types of agricultural products
                        </p>
                    </div>
                </div>
            </div>
        </footer>








        <!-- Copyright Section-->
        <div class="copyright py-4 text-center text-white">
            <div class="container"><small>Copyright © AGRO-COMMERS 2020</small></div>
        </div>
        <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes)-->
        <div class="scroll-to-top d-lg-none position-fixed">
            <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top"><i class="fa fa-chevron-up"></i></a>
        </div>
        
        <!-- Bootstrap core JS-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Third party plugin JS-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
        <!-- Core theme JS-->
        <script src="/js/scripts.js"></script>
         <script>
      $(document).ready(()=>{
        $('#searchKey').on('keyup',()=>{
        var searchKey= $('#searchKey').val();
        $.ajax({
            method: 'GET',
            url:"{{ route('manager.search') }}",
            data: {key: searchKey},
            dataType: 'json',
            success:(res)=>{
              var data='';
              for(var i=0; i<res.length; i++){
                data+= "<tr>"
                  +"<td>"+res[i]['nid']+"</td>"
                  +"<td>"+res[i]['uid']+"</td>"
                  +"<td>"+res[i]['notice']+"</td>"
                  +"<td colspan='2'>"
                    +"<a href='/userAdminEdit/"+res[i]['nid']+"'>Edit</a> |"
                    +"<a href='/userAdminDelete/"+res[i]['nid']+"'>Delete</a>"
                  +'</td>'
                +'</tr>';
              }
              $('#table-body').html(data);
            },
            error:(res)=>{alert('Error serching!!!!!!!!');}
          });
        });
      });
    </script>
    </body>
</html>
